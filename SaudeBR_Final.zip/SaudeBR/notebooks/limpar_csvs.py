import os
import glob
import pandas as pd

# Diretórios
csv_dir = os.path.join(os.path.dirname(__file__), '../ingestao/csvs')
output_dir = os.path.join(os.path.dirname(__file__), 'dados_limpios')
os.makedirs(output_dir, exist_ok=True)

# Exemplo de dicionários (ajuste conforme necessário)
dic_cid10 = {}  # Carregue um dicionário real depois
dic_municipios = {}  # Carregue um dicionário real depois

def limpar_df(df):
    # Exemplo: padronizar nomes de colunas para minúsculo
    df.columns = [col.lower() for col in df.columns]
    # Exemplo: remover espaços
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    # Exemplo: tratar nulos
    df = df.fillna('')
    # Exemplo: mapear códigos (ajuste para colunas reais)
    # df['cid10_desc'] = df['cid10'].map(dic_cid10)
    # df['municipio_nome'] = df['municipio'].map(dic_municipios)
    return df

csv_files = glob.glob(os.path.join(csv_dir, '*.csv'))

for csv_file in csv_files:
    print(f'Limpando {csv_file}...')
    df = pd.read_csv(csv_file, dtype=str)
    df = limpar_df(df)
    nome_csv = os.path.basename(csv_file)
    output_path = os.path.join(output_dir, nome_csv)
    df.to_csv(output_path, index=False)
    print(f'Salvo: {output_path}')

print('Limpeza concluída!')
