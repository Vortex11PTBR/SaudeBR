import glob
import os
import re

import pandas as pd
from sqlalchemy import create_engine

# Ajuste sua string de conexão aqui
CONN_STR = "postgresql://neondb_owner:npg_Qibz9mqoGT5c@ep-orange-poetry-acymxvoo-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
engine = create_engine(CONN_STR)

# Caminhos das pastas
base = (
    r"C:\Users\joaop\OneDrive\Desktop\joaolacerda.dev\projetos\fullstack\SaudeBR\dados"
)
paths = {
    "fato_internacoes": os.path.join(base, "sih-sus", "*.csv"),
    "fato_mortalidade": os.path.join(base, "cid-10", "*.csv"),
    "dim_geografica": os.path.join(
        base, "DTB_2024", "RELATORIO_DTB_BRASIL_2024_MUNICIPIOS.csv"
    ),
}

# Carregar SIH-SUS
for file in glob.glob(paths["fato_internacoes"]):
    # Encontrar a linha do cabeçalho real e o período
    with open(file, encoding="latin1") as f:
        lines = f.readlines()
    header_idx = None
    periodo = None
    for idx, line in enumerate(lines):
        if "Período:" in line:
            periodo_match = re.search(r"Período:([A-Za-z]{3}/\d{4})", line)
            if periodo_match:
                periodo = periodo_match.group(1)
        if "Município;" in line or "Município;" in line.replace('"', ""):
            header_idx = idx
            break
    if header_idx is None:
        print(f"Cabeçalho não encontrado em {file}")
        continue
    skip = header_idx
    try:
        df = pd.read_csv(file, encoding="latin1", sep=";", skiprows=skip)
        # Separar código e nome do município
        df[["cod_municipio", "nome_municipio"]] = df["Município"].str.extract(
            r"(\d{6,7})\s+(.+)"
        )
        df["periodo"] = periodo if periodo else ""
        df = df[["cod_municipio", "nome_municipio", "Internações", "periodo"]]
        print(f"Arquivo: {file}")
        print(df.head(5))
        # df.to_sql("fato_internacoes", engine, if_exists="append", index=False)
    except Exception as e:
        print(f"Erro ao ler {file}: {e}")
        continue

for file in glob.glob(paths["fato_mortalidade"]):
    with open(file, encoding="latin1") as f:
        lines = f.readlines()
    header_idx = None
    periodo = None
    for idx, line in enumerate(lines):
        if "Período:" in line:
            periodo_match = re.search(r"Período:([A-Za-z]{3}/\d{4})", line)
            if periodo_match:
                periodo = periodo_match.group(1)
        if "Município;" in line or "Município;" in line.replace('"', ""):
            header_idx = idx
            break
    if header_idx is None:
        print(f"Cabeçalho não encontrado em {file}")
        continue
    skip = header_idx
    try:
        df = pd.read_csv(file, encoding="latin1", sep=";", skiprows=skip)
        df[["cod_municipio", "nome_municipio"]] = df["Município"].str.extract(
            r"(\d{6,7})\s+(.+)"
        )
        df["periodo"] = periodo if periodo else ""
        # Ajuste o nome da coluna de óbitos conforme o arquivo, ex: "Óbitos"
        if "Óbitos" in df.columns:
            df = df[["cod_municipio", "nome_municipio", "Óbitos", "periodo"]]
            df.to_sql("fato_mortalidade", engine, if_exists="append", index=False)
        else:
            print(f"Coluna 'Óbitos' não encontrada em {file}")
        print(f"Arquivo: {file}")
        print(df.head(5))
    except Exception as e:
        print(f"Erro ao ler {file}: {e}")
        continue
# Carregar CID-10
for file in glob.glob(paths["fato_mortalidade"]):
    df = pd.read_csv(file, encoding="latin1", on_bad_lines="skip")
    df.to_sql("fato_mortalidade", engine, if_exists="append", index=False)

# Carregar dimensão geográfica
df_geo = pd.read_csv(paths["dim_geografica"], encoding="latin1", on_bad_lines="skip")
df_geo.to_sql("dim_geografica", engine, if_exists="append", index=False)

print("Carga concluída!")
