import pandas as pd
import glob

dtb = pd.read_csv('../dicionarios/dtb_municipios_padronizado.csv')

def padronizar_arquivo(path, tipo):
    df = pd.read_csv(path, sep=';', encoding='utf-8')
    df.columns = [c.strip().lower() for c in df.columns]
    df['municipio'] = df['municipio'].str.extract(r'(\d{6,7})')[0].str.zfill(7)
    df = df.merge(dtb, left_on='municipio', right_on='codigo_municipio', how='left')
    if tipo == 'sih':
        df = df.rename(columns={'internações': 'quantidade'})
    elif tipo == 'cid10':
        df = df.rename(columns={'óbitos_p/residênc': 'quantidade'})
    df['ano'] = path[-12:-8]  # Ajuste conforme padrão do nome do arquivo
    return df[['codigo_municipio', 'nome_municipio', 'uf', 'ano', 'quantidade']]

arquivos_sih = glob.glob(r'C:/Users/joaop/Downloads/sih-sus/*jun*.csv') + glob.glob(r'C:/Users/joaop/Downloads/sih-sus/*dez*.csv')
df_sih = pd.concat([padronizar_arquivo(f, 'sih') for f in arquivos_sih])
df_sih.to_csv('../dicionarios/sih_sus_padronizado.csv', index=False)

arquivos_cid10 = glob.glob(r'C:/Users/joaop/Downloads/cid-10/*.csv')
df_cid10 = pd.concat([padronizar_arquivo(f, 'cid10') for f in arquivos_cid10])
df_cid10.to_csv('../dicionarios/cid10_padronizado.csv', index=False)
