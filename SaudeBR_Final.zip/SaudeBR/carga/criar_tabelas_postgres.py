from sqlalchemy import create_engine, text

engine = create_engine('postgresql://usuario:senha@host:porta/banco?sslmode=require')

CREATE_TABLES = [
    '''CREATE TABLE IF NOT EXISTS dim_municipio (
        id SERIAL PRIMARY KEY,
        codigo_municipio VARCHAR(7) UNIQUE,
        nome_municipio VARCHAR(100),
        uf VARCHAR(2)
    );''',
    '''CREATE TABLE IF NOT EXISTS fato_internacoes (
        id SERIAL PRIMARY KEY,
        codigo_municipio VARCHAR(7),
        ano INT,
        quantidade INT,
        FOREIGN KEY (codigo_municipio) REFERENCES dim_municipio(codigo_municipio)
    );''',
    '''CREATE TABLE IF NOT EXISTS fato_mortalidade (
        id SERIAL PRIMARY KEY,
        codigo_municipio VARCHAR(7),
        ano INT,
        quantidade INT,
        FOREIGN KEY (codigo_municipio) REFERENCES dim_municipio(codigo_municipio)
    );'''
]

with engine.connect() as conn:
    for stmt in CREATE_TABLES:
        conn.execute(text(stmt))
    conn.commit()
