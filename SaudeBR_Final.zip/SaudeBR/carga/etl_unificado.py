import pandas as pd
import glob
import os
from sqlalchemy import create_engine, text

# Configurações
CONN_STR = 'postgresql://neondb_owner:npg_Qibz9mqoGT5c@ep-orange-poetry-acymxvoo-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
BASE_DIR = '/home/ubuntu/saudebr/SaudeBR'
DTB_PATH = os.path.join(BASE_DIR, 'dicionarios/dtb_municipios_padronizado.csv')
SIH_DIR = os.path.join(BASE_DIR, 'dados/sih-sus')
SIM_DIR = os.path.join(BASE_DIR, 'dados/cid-10')

engine = create_engine(CONN_STR)

def criar_schema():
    print("Criando/Verificando tabelas...")
    statements = [
        "DROP TABLE IF EXISTS fato_internacoes CASCADE;",
        "DROP TABLE IF EXISTS fato_mortalidade CASCADE;",
        "DROP TABLE IF EXISTS dim_tempo CASCADE;",
        "DROP TABLE IF EXISTS dim_geografica CASCADE;",
        "DROP TABLE IF EXISTS dim_cid10 CASCADE;",
        
        """CREATE TABLE dim_tempo (
            id SERIAL PRIMARY KEY,
            ano INT,
            mes INT,
            UNIQUE(ano, mes)
        );""",
        """CREATE TABLE dim_geografica (
            id SERIAL PRIMARY KEY,
            codigo_municipio VARCHAR(7) UNIQUE,
            nome_municipio VARCHAR(100),
            uf VARCHAR(2)
        );""",
        """CREATE TABLE dim_cid10 (
            id SERIAL PRIMARY KEY,
            codigo_cid10 VARCHAR(10) UNIQUE,
            descricao VARCHAR(255)
        );""",
        """CREATE TABLE fato_internacoes (
            id SERIAL PRIMARY KEY,
            tempo_id INT REFERENCES dim_tempo(id),
            geo_id INT REFERENCES dim_geografica(id),
            cid10_id INT REFERENCES dim_cid10(id),
            quantidade INT
        );""",
        """CREATE TABLE fato_mortalidade (
            id SERIAL PRIMARY KEY,
            tempo_id INT REFERENCES dim_tempo(id),
            geo_id INT REFERENCES dim_geografica(id),
            cid10_id INT REFERENCES dim_cid10(id),
            quantidade INT
        );"""
    ]
    with engine.connect() as conn:
        for stmt in statements:
            conn.execute(text(stmt))
        conn.commit()

def carregar_dim_geografica():
    print("Carregando dim_geografica...")
    df = pd.read_csv(DTB_PATH)
    df['codigo_municipio'] = df['codigo_municipio'].astype(str).str.zfill(7)
    df.to_sql('dim_geografica', engine, if_exists='append', index=False, method='multi')

def extrair_data(filename):
    try:
        with open(filename, 'r', encoding='iso-8859-1') as f:
            for line in f:
                if "Período:" in line:
                    periodo = line.split("Período:")[1].strip()
                    if '/' in periodo:
                        mes_str, ano = periodo.split('/')
                        meses = {'Jan':1, 'Fev':2, 'Mar':3, 'Abr':4, 'Mai':5, 'Jun':6, 
                                 'Jul':7, 'Ago':8, 'Set':9, 'Out':10, 'Nov':11, 'Dez':12}
                        return int(ano), meses.get(mes_str, 1)
    except:
        pass
    return 2022, 6

def processar_arquivos(diretorio, tabela_fato, label):
    print(f"Processando {label}...")
    arquivos = glob.glob(os.path.join(diretorio, '*.csv'))
    
    # Garantir CID TOTAL
    with engine.connect() as conn:
        conn.execute(text("INSERT INTO dim_cid10 (codigo_cid10, descricao) VALUES ('TOTAL', 'Todas as causas') ON CONFLICT DO NOTHING"))
        conn.commit()
        cid_id = conn.execute(text("SELECT id FROM dim_cid10 WHERE codigo_cid10='TOTAL'")).fetchone()[0]
    
    geo_map = pd.read_sql("SELECT id as geo_id, codigo_municipio FROM dim_geografica", engine)
    
    for f in arquivos:
        ano, mes = extrair_data(f)
        
        with engine.connect() as conn:
            conn.execute(text("INSERT INTO dim_tempo (ano, mes) VALUES (:a, :m) ON CONFLICT (ano, mes) DO NOTHING"), {"a": ano, "m": mes})
            conn.commit()
            tempo_id = conn.execute(text("SELECT id FROM dim_tempo WHERE ano=:a AND mes=:m"), {"a": ano, "m": mes}).fetchone()[0]

        df = pd.read_csv(f, sep=';', encoding='iso-8859-1', skiprows=3)
        df = df[df.iloc[:, 0].str.contains(r'^\d', na=False)].copy()
        df.columns = ['municipio_raw', 'quantidade']
        
        # Extrair 6 dígitos e bater com o geo_map (que tem 7)
        df['cod6'] = df['municipio_raw'].str.extract(r'^(\d{6})')[0]
        geo_map['cod6'] = geo_map['codigo_municipio'].str[:6]
        
        df = df.merge(geo_map, on='cod6', how='inner')
        
        df_fato = pd.DataFrame({
            'tempo_id': tempo_id,
            'geo_id': df['geo_id'],
            'cid10_id': cid_id,
            'quantidade': pd.to_numeric(df['quantidade'], errors='coerce').fillna(0).astype(int)
        })
        
        df_fato.to_sql(tabela_fato, engine, if_exists='append', index=False, method='multi')
        print(f"Arquivo {os.path.basename(f)} carregado em {tabela_fato}.")

if __name__ == "__main__":
    criar_schema()
    carregar_dim_geografica()
    processar_arquivos(SIH_DIR, 'fato_internacoes', 'Internações (SIH)')
    processar_arquivos(SIM_DIR, 'fato_mortalidade', 'Mortalidade (SIM)')
    print("ETL concluído com sucesso!")
