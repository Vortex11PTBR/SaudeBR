import os
import glob
import pandas as pd
from sqlalchemy import create_engine, text

# Connection string do Neon
CONN_STR = 'postgresql://neondb_owner:npg_Qibz9mqoGT5c@ep-orange-poetry-acymxvoo-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'

# Diretório dos dados limpos
base_dir = os.path.dirname(os.path.dirname(__file__))
dados_dir = os.path.join(base_dir, 'transformacao', 'dados_limpios')

# Exemplo de criação de tabelas (ajuste conforme necessário)
CREATE_TABLES = [
    '''CREATE TABLE IF NOT EXISTS dim_tempo (
        id SERIAL PRIMARY KEY,
        ano INT,
        mes INT
    );''',
    '''CREATE TABLE IF NOT EXISTS dim_geografica (
        id SERIAL PRIMARY KEY,
        uf VARCHAR(2),
        municipio VARCHAR(100)
    );''',
    '''CREATE TABLE IF NOT EXISTS dim_cid10 (
        id SERIAL PRIMARY KEY,
        cid10 VARCHAR(10),
        descricao VARCHAR(255)
    );''',
    '''CREATE TABLE IF NOT EXISTS fato_internacoes (
        id SERIAL PRIMARY KEY,
        tempo_id INT REFERENCES dim_tempo(id),
        geo_id INT REFERENCES dim_geografica(id),
        cid10_id INT REFERENCES dim_cid10(id),
        quantidade INT
    );'''
]

def conectar():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )

def criar_tabelas(engine):
    with engine.connect() as conn:
        for stmt in CREATE_TABLES:
            conn.execute(text(stmt))
        conn.commit()

def carregar_dados():
    engine = create_engine(CONN_STR)
    criar_tabelas(engine)
    # Carregar CSVs para uma tabela staging_internacoes
    csv_files = glob.glob(os.path.join(dados_dir, '*.csv'))
    # Criação explícita da tabela staging_internacoes
    if csv_files:
        df_sample = pd.read_csv(csv_files[0], dtype=str, nrows=1)
        df_sample.iloc[0:0].to_sql('staging_internacoes', engine, if_exists='replace', index=False)
    for csv_file in csv_files:
        print(f'Carregando {csv_file}...')
        df = pd.read_csv(csv_file, dtype=str)
        df.to_sql('staging_internacoes', engine, if_exists='append', index=False, method='multi')
        print(f'Inserido: {csv_file}')
    print('Carga concluída!')

if __name__ == '__main__':
    carregar_dados()
