import pandas as pd
import os

# Caminho do arquivo ODS
ods_path = r'../dados/DTB_2024/RELATORIO_DTB_BRASIL_2024_DISTRITOS.ods'
# Caminho de saída CSV
csv_path = r'../dicionarios/dtb_municipios_padronizado.csv'

# Lê a primeira planilha do ODS
try:
    df = pd.read_excel(ods_path, engine='odf')
except Exception as e:
    print(f'Erro ao ler ODS: {e}')
    exit(1)

# Tenta identificar colunas de código e nome do município
possiveis_colunas = [c for c in df.columns if 'munic' in c.lower() or 'código' in c.lower() or 'uf' in c.lower()]
print('Colunas encontradas:', possiveis_colunas)

# Ajuste conforme necessário
col_codigo = [c for c in possiveis_colunas if 'código' in c.lower()][0]
col_nome = [c for c in possiveis_colunas if 'nome' in c.lower()][0]
col_uf = [c for c in possiveis_colunas if 'uf' in c.lower()][0]

# Padroniza e salva
df_out = df[[col_codigo, col_nome, col_uf]].copy()
df_out.columns = ['codigo_municipio', 'nome_municipio', 'uf']
df_out['codigo_municipio'] = df_out['codigo_municipio'].astype(str).str.zfill(7)
df_out.to_csv(csv_path, index=False, encoding='utf-8')
print(f'Arquivo salvo em {csv_path}')
