import pandas as pd

df = pd.read_excel(r'C:/Users/joaop/Downloads/DTB_2024/RELATORIO_DTB_BRASIL_2024_MUNICIPIOS.xls', skiprows=5)
df = df.rename(columns={
    'Código Município Completo': 'codigo_municipio',
    'Nome_Município': 'nome_municipio',
    'UF': 'uf'
})
df = df[['codigo_municipio', 'nome_municipio', 'uf']]
df['codigo_municipio'] = df['codigo_municipio'].astype(str).str.zfill(7)
df.to_csv('dtb_municipios_padronizado.csv', index=False)
