import os
import glob
import pandas as pd
from dbcpy import DBCReader

# Diretório dos arquivos DBC baixados
dbc_dir = os.path.join(os.path.dirname(__file__), 'dados_brutos')
output_dir = os.path.join(os.path.dirname(__file__), 'csvs')
os.makedirs(output_dir, exist_ok=True)

# Lista todos os arquivos DBC no diretório
dbc_files = glob.glob(os.path.join(dbc_dir, '*.DBC'))

for dbc_file in dbc_files:
    print(f'Lendo {dbc_file}...')
    with DBCReader(dbc_file) as reader:
        df = pd.DataFrame(list(reader))
    nome_csv = os.path.splitext(os.path.basename(dbc_file))[0] + '.csv'
    csv_path = os.path.join(output_dir, nome_csv)
    df.to_csv(csv_path, index=False)
    print(f'Salvo: {csv_path}')

print('Conversão concluída!')
