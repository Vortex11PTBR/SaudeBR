from sqlalchemy import create_engine
import pandas as pd

CONN_STR = 'postgresql://neondb_owner:npg_Qibz9mqoGT5c@ep-orange-poetry-acymxvoo-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'

engine = create_engine(CONN_STR)
with engine.connect() as conn:
    df = pd.read_sql("""
        SELECT table_schema, table_name
        FROM information_schema.tables
        WHERE table_type = 'BASE TABLE'
        ORDER BY table_schema, table_name
    """, conn)
    print(df)
