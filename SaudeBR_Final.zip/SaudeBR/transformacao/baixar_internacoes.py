import os
import requests

# Diretório para salvar os arquivos baixados
download_dir = os.path.join(os.path.dirname(__file__), 'dados_brutos')
os.makedirs(download_dir, exist_ok=True)

# Exemplo de URL de dataset SIH/SUS (ajuste conforme necessário)
BASE_URL = 'https://datasus.saude.gov.br/transferencia-de-arquivos/'

# Função para baixar arquivo (exemplo genérico)
def baixar_arquivo(url, destino):
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        with open(destino, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f'Arquivo salvo em: {destino}')
    else:
        print(f'Erro ao baixar: {url}')

if __name__ == '__main__':
    # Exemplo: baixar todos os arquivos de internação do SIH/SUS para 2023, todos estados
    estados = [
        'AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT',
        'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO'
    ]
    ano = 2023
    base_url = 'https://ftp.datasus.gov.br/dissemin/publicos/SIHSUS/200801_/Dados/'
    for uf in estados:
        nome_arquivo = f'{uf}{ano}.DBC'
        url = base_url + nome_arquivo
        destino = os.path.join(download_dir, nome_arquivo)
        print(f'Baixando {url}...')
        baixar_arquivo(url, destino)
    print('Download concluído para todos os estados.')
