import pandas as pd
from sqlalchemy import create_engine, text
import os

# Connection string do Neon
CONN_STR = 'postgresql://neondb_owner:npg_Qibz9mqoGT5c@ep-orange-poetry-acymxvoo-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'

def popular_dimensoes_e_fato():
    engine = create_engine(CONN_STR)
    with engine.connect() as conn:
        # Carregar staging_internacoes
        df = pd.read_sql('SELECT * FROM staging_internacoes', conn)
        # Popular dim_tempo
        tempo = df[['ano', 'mes']].drop_duplicates().astype({'ano': int, 'mes': int})
        tempo.to_sql('dim_tempo', engine, if_exists='append', index=False, method='multi')
        # Popular dim_geografica
        geo = df[['uf', 'municipio']].drop_duplicates()
        geo.to_sql('dim_geografica', engine, if_exists='append', index=False, method='multi')
        # Popular dim_cid10
        if 'cid10_desc' in df.columns:
            cid = df[['cid10', 'cid10_desc']].drop_duplicates()
            cid.columns = ['cid10', 'descricao']
        else:
            cid = df[['cid10']].drop_duplicates()
            cid['descricao'] = ''
        cid.to_sql('dim_cid10', engine, if_exists='append', index=False, method='multi')
        # Obter ids das dimensões
        tempo_dim = pd.read_sql('SELECT * FROM dim_tempo', conn)
        geo_dim = pd.read_sql('SELECT * FROM dim_geografica', conn)
        cid_dim = pd.read_sql('SELECT * FROM dim_cid10', conn)
        # Juntar para montar fato_internacoes
        fato = df.merge(tempo_dim, on=['ano', 'mes']) \
                  .merge(geo_dim, on=['uf', 'municipio']) \
                  .merge(cid_dim, on=['cid10'])
        fato_final = fato[['id_x', 'id_y', 'id', 'quantidade']]
        fato_final.columns = ['tempo_id', 'geo_id', 'cid10_id', 'quantidade']
        fato_final.to_sql('fato_internacoes', engine, if_exists='append', index=False, method='multi')
        print('Dimensões e fato populados!')

if __name__ == '__main__':
    popular_dimensoes_e_fato()
