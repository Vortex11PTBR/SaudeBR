# SaúdeBR — Painel de Inteligência da Saúde Pública Brasileira

Este documento descreve a estrutura do banco de dados e as instruções para conexão com o Power BI para o projeto **SaúdeBR**.

## Estrutura do Banco de Dados (Schema Estrela)

O banco de dados foi modelado seguindo as melhores práticas de Business Intelligence, utilizando um **Star Schema** para otimizar a performance analítica.

### Tabelas de Dimensão
- **dim_tempo**: Contém a granularidade de Ano e Mês.
- **dim_geografica**: Contém informações de Município (Código IBGE 7 dígitos), Nome do Município e UF.
- **dim_cid10**: Contém os códigos e descrições da Classificação Internacional de Doenças (CID-10).

### Tabelas de Fato
- **fato_internacoes**: Registros de internações hospitalares (SIH/SUS).
- **fato_mortalidade**: Registros de óbitos por local de residência (SIM).
- **fato_capacidade**: Registros de leitos hospitalares por município (CNES).

## Dados Processados
- **Fonte**: DATASUS (SIH, SIM, CNES) e IBGE (DTB).
- **Abrangência**: Nacional (todos os municípios brasileiros).
- **Período**: Junho/2022 (Dados de exemplo carregados).

## Guia de Conexão Power BI

Para conectar o Power BI ao banco de dados Neon (PostgreSQL), siga os passos abaixo:

1. Abra o **Power BI Desktop**.
2. Clique em **Obter Dados** > **Banco de dados PostgreSQL**.
3. Insira as seguintes credenciais:
   - **Servidor**: `ep-orange-poetry-acymxvoo-pooler.sa-east-1.aws.neon.tech`
   - **Banco de Dados**: `neondb`
4. Em **Opções Avançadas**, certifique-se de que a opção **Requer SSL** está marcada (ou adicione `?sslmode=require` à connection string se solicitado).
5. No prompt de autenticação:
   - **Usuário**: `neondb_owner`
   - **Senha**: `npg_Qibz9mqoGT5c`
6. Clique em **Conectar**.
7. Selecione as tabelas: `dim_tempo`, `dim_geografica`, `dim_cid10`, `fato_internacoes`, `fato_mortalidade` e `fato_capacidade`.

## Medidas DAX Recomendadas

Para análise epidemiológica correta, utilize a **Taxa por 100 mil habitantes**:

```dax
Taxa Internação = 
DIVIDE(
    SUM(fato_internacoes[quantidade]),
    [Populacao_Total] -- Você pode adicionar uma dimensão de população
) * 100000
```

---
*Projeto construído para demonstração de maturidade técnica em Engenharia de Dados e BI.*
